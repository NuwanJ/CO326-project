
This is the software should be run on the host machine, which is connected to the CNC
Please run following command before the first run

> npm install


Please make sure to connect the machine to the PC and sspecify the COM port when running the server.

Ex:
> npm start COM4